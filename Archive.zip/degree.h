//r
// Created by Kyle on 3/1/24.
//

#ifndef C867_DEGREE_H
#define C867_DEGREE_H

enum DegreeProgram {
    SECURITY = 1,
    NETWORK = 2,
    SOFTWARE = 3
};

#endif //C867_DEGREE_H

